import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { SiteFooter, SiteNav } from "../components/site-chrome";

function NotFoundComponent() {
  return (
    <div className="flex items-center justify-center px-6 py-32">
      <div className="max-w-lg text-center panel brackets p-10">
        <span className="b-tr" />
        <span className="b-bl" />
        <div className="mono text-[11px] uppercase tracking-widest text-critical mb-4">
          ERR_404 // ACCESS DENIED
        </div>
        <h1 className="text-6xl font-display font-bold text-foreground">404</h1>
        <p className="mt-4 text-sm text-muted-foreground mono">
          The resource you requested is not indexed on this perimeter.
        </p>
        <div className="mt-8">
          <Link
            to="/"
            className="mono text-[11px] uppercase tracking-widest inline-flex items-center gap-2 border border-signal/60 text-signal px-5 py-3 hover:bg-signal hover:text-signal-foreground transition-colors"
          >
            ← Return to base
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center panel brackets p-10">
        <span className="b-tr" />
        <span className="b-bl" />
        <div className="mono text-[11px] uppercase tracking-widest text-critical mb-4">
          ERR // UNCAUGHT_EXCEPTION
        </div>
        <h1 className="text-xl font-display font-semibold text-foreground">
          This page did not load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Retry the request or return to base.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="mono text-[11px] uppercase tracking-widest border border-signal/60 text-signal px-4 py-2 hover:bg-signal hover:text-signal-foreground transition-colors"
          >
            Retry
          </button>
          <a
            href="/"
            className="mono text-[11px] uppercase tracking-widest border border-hairline px-4 py-2 hover:border-foreground/40 transition-colors"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "techvrs — SOC Analyst & Security-First Engineer" },
      {
        name: "description",
        content:
          "Secure by Design. Threat detection, hardened deployments, technical SEO, and secure AI agent development by a SOC analyst.",
      },
      { name: "author", content: "techvrs" },
      { name: "theme-color", content: "#0A0E14" },
      { property: "og:title", content: "techvrs — SOC Analyst & Security-First Engineer" },
      {
        property: "og:description",
        content:
          "SOC analyst portfolio and freelance security studio. Detection, secure web deployment, technical SEO, and secure AI agents.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "techvrs — SOC Analyst & Security-First Engineer" },
      {
        name: "twitter:description",
        content:
          "SOC analyst portfolio and freelance security studio. Detection, secure web deployment, technical SEO, and secure AI agents.",
      },
      { name: "description", content: "A cybersecurity analyst's portfolio and freelance studio, designed as a live operations console." },
      { property: "og:description", content: "A cybersecurity analyst's portfolio and freelance studio, designed as a live operations console." },
      { name: "twitter:description", content: "A cybersecurity analyst's portfolio and freelance studio, designed as a live operations console." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/a2959f9b-7b98-4c88-a158-30e3d02dabc9/id-preview-a98e4ae7--89e36b74-5646-417a-962b-64b82141564f.lovable.app-1782924225861.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/a2959f9b-7b98-4c88-a158-30e3d02dabc9/id-preview-a98e4ae7--89e36b74-5646-417a-962b-64b82141564f.lovable.app-1782924225861.png" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "icon", href: "/favicon.ico", type: "image/x-icon" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap",
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen flex flex-col">
        <SiteNav />
        <main className="flex-1">
          <Outlet />
        </main>
        <SiteFooter />
      </div>
    </QueryClientProvider>
  );
}
