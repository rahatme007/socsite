import { createFileRoute, Link } from "@tanstack/react-router";
import { Panel, SectionLabel, StatusPulse } from "@/components/site-chrome";
import { ParticleBackground } from "@/components/particle-background";
import { services, caseStudies, skills } from "@/content/site-data";
import heroShield from "@/assets/hero-shield.png.asset.json";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  return (
    <>
      <Hero />
      <TrustBar />
      <ServicesOverview />
      <FeaturedWork />
      <SkillsMatrix />
      <BlogPreview />
      <CtaBand />
    </>
  );
}

function WireframeShield() {
  return (
    <svg
      viewBox="0 0 200 220"
      className="w-full h-full text-signal"
      fill="none"
      stroke="currentColor"
      strokeWidth="1"
      aria-hidden
    >
      <path d="M100 10 L180 45 V115 C180 165 140 200 100 210 C60 200 20 165 20 115 V45 Z" opacity="0.7" />
      <path d="M100 30 L160 58 V115 C160 152 130 182 100 190 C70 182 40 152 40 115 V58 Z" opacity="0.4" />
      <path d="M100 10 V210 M20 80 H180 M20 130 H180" opacity="0.35" strokeDasharray="2 4" />
      <circle cx="100" cy="110" r="6" fill="currentColor" />
      <circle cx="100" cy="110" r="14" opacity="0.5" />
      <circle cx="100" cy="110" r="24" opacity="0.25" />
      <path d="M70 105 L95 130 L135 90" strokeWidth="2" />
    </svg>
  );
}

function Hero() {
  return (
    <section className="relative overflow-hidden">
      <ParticleBackground className="absolute inset-0 h-full w-full z-0" />
      <div className="absolute inset-0 bg-grid opacity-40 z-[1]" aria-hidden />
      <div className="absolute inset-0 bg-scanlines opacity-60 z-[1]" aria-hidden />
      <div className="absolute inset-0 bg-datagrid pointer-events-none z-[1]" aria-hidden />
      <div className="absolute -top-40 -right-40 h-[500px] w-[500px] bg-signal/20 blur-[120px] z-[1]" aria-hidden />
      <div className="absolute -bottom-40 -left-40 h-[400px] w-[400px] bg-signal/10 blur-[120px] z-[1]" aria-hidden />


      <div className="relative z-10 mx-auto max-w-7xl px-6 pt-24 pb-32 md:pt-32 md:pb-40 grid lg:grid-cols-[1fr_auto] gap-12 items-start">
        <div>
          <div className="mono text-[11px] uppercase tracking-[0.3em] text-signal mb-8 reveal">
            <span className="pulse-dot mr-3" /> SOC ANALYST // SECURITY-FIRST ENGINEER
          </div>
          <h1 className="reveal font-display text-5xl md:text-7xl lg:text-8xl font-bold leading-[0.95] max-w-5xl">
            <span className="type-in">Secure by Design.</span>
            <br />
            <span className="text-signal">Built to Withstand</span> What Others Miss.
          </h1>
          <p className="reveal mt-8 max-w-2xl text-lg text-muted-foreground leading-relaxed">
            Practical threat detection, hardened infrastructure, and intelligent automation
            — engineered with the same discipline used to defend production environments.
            I don't just build systems; I build systems that hold under pressure.
          </p>

          <div className="reveal mt-10 flex flex-wrap gap-4">
            <Link
              to="/work"
              className="group mono text-[11px] uppercase tracking-widest inline-flex items-center gap-3 bg-signal text-signal-foreground px-6 py-4 hover:shadow-[0_0_40px_-2px_rgba(0,217,255,0.55)]"
            >
              View my SOC portfolio
              <span className="transition-transform group-hover:translate-x-1">→</span>
            </Link>
            <Link
              to="/contact"
              className="group mono text-[11px] uppercase tracking-widest inline-flex items-center gap-3 border border-signal/60 text-signal px-6 py-4 hover:bg-signal/10 hover:shadow-[0_0_28px_-4px_rgba(0,217,255,0.45)]"
            >
              Hire me for a project
              <span className="transition-transform group-hover:translate-x-1">→</span>
            </Link>
          </div>

          <div className="reveal mt-12 border-t border-hairline pt-6">
            <StatusPulse />
          </div>
        </div>

        <div className="hidden lg:block reveal">
          <div className="relative w-[380px] h-[380px] float-y">
            <div className="absolute inset-0 bg-signal/20 blur-[80px]" aria-hidden />
            <div className="relative panel brackets p-3 w-full h-full flex items-center justify-center overflow-hidden">
              <span className="b-tr" />
              <span className="b-bl" />
              <img
                src={heroShield.url}
                alt="Isometric SOC analyst holding a holographic shield surrounded by security dashboards"
                className="relative w-full h-full object-cover"
                loading="eager"
              />
              <div className="absolute top-3 left-3 mono text-[9px] uppercase tracking-widest text-signal z-10">
                NODE.01
              </div>
              <div className="absolute bottom-3 right-3 mono text-[9px] uppercase tracking-widest text-signal/80 z-10">
                INTEGRITY: 100%
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}

function TrustBar() {
  const items = [
    "Splunk", "MITRE ATT&CK", "AWS", "Cloudflare", "Wazuh", "NIST CSF", "OWASP",
  ];
  return (
    <section className="border-y border-hairline bg-panel/40">
      <div className="mx-auto max-w-7xl px-6 py-8 flex flex-wrap items-center justify-between gap-6">
        <div className="mono text-[10px] uppercase tracking-widest text-muted-foreground">
          TRUSTED TOOLING &amp; FRAMEWORKS
        </div>
        <div className="flex flex-wrap items-center gap-x-8 gap-y-3">
          {items.map((i) => (
            <span
              key={i}
              className="mono text-xs uppercase tracking-widest text-foreground/70 hover:text-signal transition-colors"
            >
              {i}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}

function ServicesOverview() {
  return (
    <section className="mx-auto max-w-7xl px-6 py-24 md:py-32">
      <div className="max-w-3xl">
        <SectionLabel>CAPABILITIES</SectionLabel>
        <h2 className="text-4xl md:text-5xl font-display font-bold">
          Four Disciplines.
          <br />
          <span className="text-signal">One Security-First Standard.</span>
        </h2>
        <p className="mt-6 text-muted-foreground text-lg">
          Every engagement — threat hunt, full deployment, or custom AI workflow — is
          held to the same principle: nothing ships until it's been evaluated the way
          an attacker would evaluate it.
        </p>
      </div>

      <div className="mt-14 grid gap-6 md:grid-cols-2">
        {services.map((s) => (
          <Panel key={s.slug} className="flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <span className="mono text-[11px] uppercase tracking-widest text-signal">
                {s.tagline}
              </span>
              <span className="mono text-xs text-muted-foreground">/ {s.index}</span>
            </div>
            <h3 className="text-2xl font-display font-semibold">{s.title}</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {s.description}
            </p>
            <ul className="mt-2 flex flex-col gap-2">
              {s.bullets.map((b) => (
                <li key={b} className="flex items-start gap-3 text-sm">
                  <span className="mt-1.5 h-1 w-3 bg-signal/70 shrink-0" />
                  <span className="text-foreground/80">{b}</span>
                </li>
              ))}
            </ul>
          </Panel>
        ))}
      </div>

      <div className="mt-16">
        <ProcessBar />
      </div>
    </section>
  );
}

function ProcessBar() {
  const steps = [
    { label: "ASSESS", caption: "Map the risk surface." },
    { label: "ARCHITECT", caption: "Design with security as structure." },
    { label: "IMPLEMENT", caption: "Build, document, ship." },
    { label: "MONITOR", caption: "Verify it holds under load." },
  ];
  return (
    <div className="panel brackets p-6 md:p-10">
      <span className="b-tr" />
      <span className="b-bl" />
      <div className="mono text-[10px] uppercase tracking-widest text-muted-foreground mb-6">
        ENGAGEMENT PROCESS // 04 PHASES
      </div>
      <div className="grid gap-6 md:grid-cols-4 relative">
        {steps.map((s, i) => (
          <div key={s.label} className="flex flex-col gap-2 relative">
            <div className="flex items-center gap-3">
              <div className="mono text-[10px] text-signal border border-signal/50 w-6 h-6 flex items-center justify-center">
                {String(i + 1).padStart(2, "0")}
              </div>
              <div className="mono text-sm font-semibold text-foreground tracking-widest">
                {s.label}
              </div>
            </div>
            <p className="text-sm text-muted-foreground pl-9">{s.caption}</p>
            {i < steps.length - 1 && (
              <div className="hidden md:block absolute top-3 left-full w-full h-px bg-hairline -translate-x-6" />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function FeaturedWork() {
  const featured = caseStudies.slice(0, 3);
  return (
    <section className="mx-auto max-w-7xl px-6 py-24 md:py-32 border-t border-hairline">
      <div className="flex flex-wrap items-end justify-between gap-6">
        <div>
          <SectionLabel>FIELD WORK</SectionLabel>
          <h2 className="text-4xl md:text-5xl font-display font-bold">Proof, not promises.</h2>
        </div>
        <Link
          to="/work"
          className="mono text-[11px] uppercase tracking-widest text-signal hover:underline underline-offset-4"
        >
          View all case studies →
        </Link>
      </div>

      <div className="mt-12 grid gap-6 md:grid-cols-3">
        {featured.map((c) => (
          <Panel key={c.slug} className="flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <span className="mono text-[10px] uppercase tracking-widest text-signal border border-signal/40 px-2 py-1">
                {c.category}
              </span>
              <span className="mono text-xs text-muted-foreground">{c.index}</span>
            </div>
            <h3 className="text-lg font-display font-semibold leading-snug">{c.title}</h3>
            <p className="text-sm text-muted-foreground line-clamp-3">{c.outcome}</p>
            <div className="mt-auto pt-4 border-t border-hairline flex flex-wrap gap-4">
              {c.metrics.slice(0, 2).map((m) => (
                <div key={m.label}>
                  <div className="mono text-signal text-xl font-semibold">{m.value}</div>
                  <div className="mono text-[9px] uppercase tracking-widest text-muted-foreground">
                    {m.label}
                  </div>
                </div>
              ))}
            </div>
          </Panel>
        ))}
      </div>
    </section>
  );
}

function SkillsMatrix() {
  return (
    <section className="mx-auto max-w-7xl px-6 py-24 md:py-32 border-t border-hairline">
      <div className="max-w-3xl">
        <SectionLabel>STACK MATRIX</SectionLabel>
        <h2 className="text-4xl md:text-5xl font-display font-bold">
          Working set: <span className="text-signal">tools of the trade.</span>
        </h2>
      </div>
      <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {Object.entries(skills).map(([group, items]) => (
          <div key={group} className="panel brackets p-5">
            <span className="b-tr" />
            <span className="b-bl" />
            <div className="mono text-[10px] uppercase tracking-widest text-signal mb-4">
              {group}
            </div>
            <ul className="flex flex-wrap gap-2">
              {items.map((s) => (
                <li
                  key={s}
                  className="mono text-[11px] px-2 py-1 border border-hairline text-foreground/80 hover:border-signal/50 hover:text-signal transition-colors"
                >
                  {s}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </section>
  );
}

function BlogPreview() {
  return (
    <section className="mx-auto max-w-7xl px-6 py-24 md:py-32 border-t border-hairline">
      <div className="flex flex-wrap items-end justify-between gap-6">
        <div>
          <SectionLabel>FIELD NOTES</SectionLabel>
          <h2 className="text-4xl md:text-5xl font-display font-bold">Notes from the console.</h2>
        </div>
        <Link to="/blog" className="mono text-[11px] uppercase tracking-widest text-signal hover:underline underline-offset-4">
          All transmissions →
        </Link>
      </div>
      <div className="mt-12 grid gap-6 md:grid-cols-3">
        {[1, 2, 3].map((i) => (
          <Panel key={i}>
            <div className="mono text-[10px] uppercase tracking-widest text-muted-foreground mb-4">
              INCOMING // TRANSMISSION 0{i}
            </div>
            <h3 className="text-lg font-display font-semibold leading-snug mb-3">
              Latest writing published to Medium.
            </h3>
            <p className="text-sm text-muted-foreground">
              The blog feed on this page pulls the most recent posts from Medium the
              moment they go live.
            </p>
            <Link
              to="/blog"
              className="mt-4 inline-flex mono text-[11px] uppercase tracking-widest text-signal"
            >
              Read on /blog →
            </Link>
          </Panel>
        ))}
      </div>
    </section>
  );
}

function CtaBand() {
  return (
    <section className="mx-auto max-w-7xl px-6 py-24">
      <div className="panel brackets p-10 md:p-16 relative overflow-hidden scan-sweep">
        <span className="b-tr" />
        <span className="b-bl" />
        <div className="absolute inset-0 bg-grid opacity-20" aria-hidden />
        <div className="relative flex flex-col md:flex-row md:items-center md:justify-between gap-8">
          <div>
            <div className="mono text-[11px] uppercase tracking-widest text-signal mb-3">
              OPEN CHANNEL
            </div>
            <h2 className="text-3xl md:text-4xl font-display font-bold max-w-2xl">
              Start a conversation. I'll respond with next steps, not a sales pitch.
            </h2>
          </div>
          <Link
            to="/contact"
            className="mono text-[11px] uppercase tracking-widest inline-flex items-center gap-3 bg-signal text-signal-foreground px-6 py-4 hover:shadow-[0_0_40px_-5px_var(--signal)] transition-shadow whitespace-nowrap"
          >
            Send transmission →
          </Link>
        </div>
      </div>
    </section>
  );
}
